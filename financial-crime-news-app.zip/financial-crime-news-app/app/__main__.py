"""Simple GUI launcher for Financial Crime News Monitor.

This GUI uses PySimpleGUI and calls into monitor.core for fetching & analysis.
It's intentionally minimal so it can be built with PyInstaller into a single exe.
"""
import os
import threading
import logging
import PySimpleGUI as sg

from monitor.core import init_db, search_and_store

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('app')

DEFAULT_DB = os.path.join(os.getenv('APPDATA') or '.', 'FinancialCrimeNews', 'articles.db')
os.makedirs(os.path.dirname(DEFAULT_DB), exist_ok=True)

class SearchThread(threading.Thread):
    def __init__(self, query, db_path, use_ml, use_ner, max_items, window, offline=False):
        super().__init__(daemon=True)
        self.query = query
        self.db_path = db_path
        self.use_ml = use_ml
        self.use_ner = use_ner
        self.max_items = max_items
        self.window = window
        self.offline = offline

    def run(self):
        conn = init_db(self.db_path)
        results = search_and_store(self.query, conn, max_items=self.max_items, use_ml=self.use_ml, use_ner=self.use_ner)
        self.window.write_event_value('-RESULTS-', results)

def build_layout():
    layout = [
        [sg.Text('Financial Crime News — Desktop (basic)')],
        [sg.Text('Keywords'), sg.Input(key='-Q-', size=(50,1))],
        [sg.Text('DB Path'), sg.Input(DEFAULT_DB, key='-DB-', size=(40,1)), sg.FolderBrowse(target='-DB-')],
        [sg.Checkbox('Use ML classifier (transformers)', key='-ML-'), sg.Checkbox('Use NER (spaCy)', key='-NER-')],
        [sg.Text('Max results'), sg.Input('25', size=(6,1), key='-MAX-')],
        [sg.Button('Search', key='-SEARCH-'), sg.Button('Exit')],
        [sg.HorizontalSeparator()],
        [sg.Text('Status:'), sg.Text('', key='-STATUS-')],
        [sg.Listbox(values=[], size=(100, 20), key='-LIST-')]
    ]
    return layout

def main():
    sg.theme('LightGrey1')
    layout = build_layout()
    window = sg.Window('Financial Crime News', layout, finalize=True)

    while True:
        event, values = window.read()
        if event in (None, 'Exit'):
            break
        if event == '-SEARCH-':
            q = values['-Q-'].strip()
            if not q:
                sg.popup('Please enter keywords to search for.')
                continue
            db_path = values['-DB-'] or DEFAULT_DB
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            try:
                max_items = int(values['-MAX-'])
            except Exception:
                max_items = 25
            use_ml = values['-ML-']
            use_ner = values['-NER-']
            window['-STATUS-'].update('Searching...')
            thread = SearchThread(q, db_path, use_ml, use_ner, max_items, window)
            thread.start()
        if event == '-RESULTS-':
            results = values[event]
            entries = [f"[{r.get('score', 0):0.3f}] {r.get('title')} — {r.get('source')}" for r in results]
            window['-LIST-'].update(entries)
            window['-STATUS-'].update(f"Done — {len(results)} articles")
    window.close()

if __name__ == '__main__':
    main()
