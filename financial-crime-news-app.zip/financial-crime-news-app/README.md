# financial-crime-news-app

Basic desktop app (Windows) source package. Build with PyInstaller to create a single `FinancialCrimeNews.exe`.

Quick build steps (Windows PowerShell):
```
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install -r requirements.txt
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed --add-data "sample_rss.xml;." app/__main__.py
```
After build, `dist/FinancialCrimeNews.exe` will be produced.

Note: this package keeps ML/NER optional. If you want ML/NER, install `transformers`, `torch`, and `spacy` separately.
