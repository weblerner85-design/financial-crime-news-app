"""Core monitoring logic (simplified for packaging).

- Uses requests + stdlib XML parsing for Google News RSS fallback (no feedparser).
- Provides heuristic classifier and DB persistence.
- Optional ML/NER functions are present but require extra packages.
"""
from __future__ import annotations
import os
import re
import json
import logging
import sqlite3
import html
import xml.etree.ElementTree as ET
from typing import List, Dict, Optional, Tuple
from datetime import datetime

import requests
from dateutil import parser as dateparser

logger = logging.getLogger(__name__)

NEWSAPI_KEY = os.environ.get("NEWSAPI_KEY") or None
DEFAULT_MAX = 25

DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT UNIQUE,
    title TEXT,
    description TEXT,
    source TEXT,
    publishedAt TEXT,
    fetched_at TEXT,
    score REAL,
    matches_json TEXT,
    entities_json TEXT,
    model TEXT,
    raw_json TEXT
);
"""


FIN_CRIME_KEYWORDS = [
    "fraud", "embezzlement", "money laundering", "bribery", "corruption",
    "insider trading", "tax evasion", "scam", "kickback", "forgery",
    "fraudulent", "misappropriation", "counterfeit", "cyber fraud",
    "ponzi", "ponzi scheme", "securities fraud", "financial crime", "extortion",
]
BOOST_SIGNALS = [
    "indicted", "charged", "pleaded", "sentenced", "investigation", "settlement",
    "fine", "penalty", "seized", "asset forfeiture", "convicted", "arrested", "probe",
]
MONEY_REGEX = re.compile(r"\\$\\s?\\d{1,3}(?:,\\d{3})*(?:\\.\\d{2})?")


def parse_rss_from_string(xml_string: str, max_items: int = DEFAULT_MAX) -> List[Dict]:
    try:
        root = ET.fromstring(xml_string)
    except ET.ParseError:
        txt = html.unescape(xml_string)
        root = ET.fromstring(txt)
    items = root.findall('.//item')
    out: List[Dict] = []
    for it in items[:max_items]:
        def get_text(tag: str) -> Optional[str]:
            el = it.find(tag)
            return html.unescape(el.text).strip() if (el is not None and el.text) else None
        out.append({
            "title": get_text('title'),
            "description": get_text('description'),
            "url": get_text('link'),
            "source": (it.find('source').text.strip() if it.find('source') is not None and it.find('source').text else None),
            "publishedAt": get_text('pubDate'),
            "content": None,
            "raw": None,
        })
    return out


def call_google_news_rss(query: str, max_items: int = DEFAULT_MAX) -> List[Dict]:
    q = query.replace(" ", "+")
    url = f"https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en"
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    content = r.content
    try:
        root = ET.fromstring(content)
    except ET.ParseError:
        txt = html.unescape(content.decode("utf-8", errors="ignore"))
        root = ET.fromstring(txt)
    items = root.findall('.//item')
    out: List[Dict] = []
    for it in items[:max_items]:
        def get_text(tag: str) -> Optional[str]:
            el = it.find(tag)
            return html.unescape(el.text).strip() if (el is not None and el.text) else None
        out.append({
            "title": get_text('title'),
            "description": get_text('description'),
            "url": get_text('link'),
            "source": (it.find('source').text.strip() if it.find('source') is not None and it.find('source').text else None),
            "publishedAt": get_text('pubDate'),
            "content": None,
            "raw": None,
        })
    return out


def classify_heuristic(article: Dict, keywords: Optional[List[str]] = None) -> Tuple[float, List[str]]:
    if keywords is None:
        keywords = FIN_CRIME_KEYWORDS
    text = " ".join([str(article.get(k, "")) for k in ("title", "description", "content") if article.get(k)])
    full = text.lower()
    matches = [kw for kw in keywords if kw.lower() in full]
    boosts = sum(1 for s in BOOST_SIGNALS if s in full)
    money = bool(MONEY_REGEX.search(full))
    base_score = len(matches) / max(1, len(keywords))
    boost_score = min(0.35, boosts * 0.08)
    money_score = 0.15 if money else 0
    score = min(1.0, base_score + boost_score + money_score)
    return round(score, 4), matches


def init_db(path: str):
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    cur.executescript(DB_SCHEMA)
    conn.commit()
    return conn


def upsert_article(conn: sqlite3.Connection, article: Dict, score: float, matches: List[str], entities: Optional[Dict], model_used: str):
    cur = conn.cursor()
    url = article.get("url")
    title = article.get("title")
    description = article.get("description")
    source = article.get("source")
    publishedAt = article.get("publishedAt")
    fetched_at = datetime.utcnow().isoformat()
    matches_json = json.dumps(matches, ensure_ascii=False)
    entities_json = json.dumps(entities or {}, ensure_ascii=False)
    raw_json = json.dumps(article.get("raw", article), default=str, ensure_ascii=False)
    try:
        cur.execute(
            "INSERT INTO articles (url, title, description, source, publishedAt, fetched_at, score, matches_json, entities_json, model, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (url, title, description, source, publishedAt, fetched_at, score, matches_json, entities_json, model_used, raw_json),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        cur.execute(
            "UPDATE articles SET title=?, description=?, source=?, publishedAt=?, fetched_at=?, score=?, matches_json=?, entities_json=?, model=?, raw_json=? WHERE url=?",
            (title, description, source, publishedAt, fetched_at, score, matches_json, entities_json, model_used, raw_json, url),
        )
        conn.commit()


def search_and_store(query: str, conn: Optional[sqlite3.Connection], max_items: int = DEFAULT_MAX, use_ml: bool = False, ml_model: Optional[str] = None, use_ner: bool = False, nlp=None, candidate_labels: Optional[List[str]] = None):
    try:
        articles = call_google_news_rss(query, max_items=max_items)
    except Exception:
        return []
    out_articles = []
    for a in articles:
        score, matches = classify_heuristic(a)
        if conn:
            upsert_article(conn, a, score, matches, None, 'heuristic')
        a_out = a.copy()
        a_out.update({"score": score, "matches": matches, "entities": None, "model": 'heuristic', "_fetched_from": 'Google RSS'})
        out_articles.append(a_out)
    return out_articles
